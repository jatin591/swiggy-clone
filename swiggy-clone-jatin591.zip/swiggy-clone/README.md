# Swiggy Clone

A simple responsive Swiggy homepage clone made with HTML and CSS for learning.

## Files
- index.html
- style.css

## Run locally
Open `index.html` in your browser.

Note: Food photos are loaded from Unsplash, so an internet connection is required.
